//
//  AddPinDelegate.swift
//  Cinder
//
//  Created by Mohamed Eltantawy on 19/11/2018.
//  Copyright © 2018 Mohamed Eltantawy. All rights reserved.
//

import UIKit
import MapKit
import Firebase

protocol AddPinDelegate {
  func addPinViewController(controller: addPinsVC, didAddCoordinate coordinate: CLLocationCoordinate2D,
    radius: Double, identifier: String, name: String)
}

class addPinsVC: UITableViewController {
  let appDelegate = UIApplication.shared.delegate as? AppDelegate
  
  
  @IBOutlet var addButton: UIBarButtonItem!
  @IBOutlet var zoomButton: UIBarButtonItem!
  @IBOutlet weak var radiusTextField: UITextField!
  @IBOutlet weak var nameTextField: UITextField!
  @IBOutlet weak var mapView: MKMapView!

  var delegate: AddPinDelegate?
  let db = Firestore.firestore()

  override func viewDidLoad() {
    super.viewDidLoad()
    navigationItem.rightBarButtonItems = [addButton, zoomButton]
    addButton.isEnabled = false
    //firebase
    //FirebaseApp.configure()
  }

  @IBAction func textFieldEditingChanged(sender: UITextField) {
    addButton.isEnabled = !radiusTextField.text!.isEmpty && !nameTextField.text!.isEmpty
  }

  @IBAction func onCancel(sender: AnyObject) {
    dismiss(animated: true, completion: nil)
  }

  @IBAction private func onAdd(sender: AnyObject) {
    let coordinate = mapView.centerCoordinate
    let radius = Double(radiusTextField.text!) ?? 0
    let identifier = NSUUID().uuidString
    let name = nameTextField.text
   //add data to firebase
   /* var ref: DocumentReference! = nil
    ref = db.collection("cinder").addDocument(data: [
      "Dog_loc": ["Latitude":coordinate.latitude ,"Longitude":coordinate.longitude],
      "Dog_name": name!,
      "Place_ID":identifier,
      "user_email": appDelegate!.sharedMail ,
      "user_uid":appDelegate!.sharedUID
    ]) { err in
      if let err = err {
        print("Error adding document: \(err)")
      } else {
        print("Document added with ID: \(ref!.documentID)")
      }
    }*/
    /************************************************/
    let Ref = db.collection("cinder")
    Ref.document((appDelegate?.sharedMail)!).setData([
      "Dog_loc": ["Latitude":coordinate.latitude ,"Longitude":coordinate.longitude],
      "Dog_name": name!,
      "Place_ID":identifier,
      "user_email": appDelegate!.sharedMail ,
      "user_uid":appDelegate!.sharedUID
   
      ])
    //
    delegate?.addPinViewController(controller: self, didAddCoordinate: coordinate, radius: radius, identifier: identifier, name: name!)
  }

  @IBAction private func onZoomToCurrentLocation(sender: AnyObject) {
    mapView.zoomToUserLocation()
  }
}
