//
//  mainMapVC.swift
//  Cinder
//
//  Created by Mohamed Eltantawy on 19/11/2018.
//  Copyright © 2018 Mohamed Eltantawy. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import Firebase

struct PreferencesKeys {
  static let savedItems = "savedItems"
}

class mainMapVC: UIViewController {
  let appDelegate = UIApplication.shared.delegate as? AppDelegate

  @IBOutlet weak var mapView: MKMapView!
  @IBOutlet weak var fakeMapView: MKMapView!

  let db = Firestore.firestore()

  var geotifications: [Geotification] = []
  var locationManager = CLLocationManager()
  
  override func viewDidLoad() {
    super.viewDidLoad()
//
    let logo = UIImage(named: "logo1")
    let imageView = UIImageView(image:logo)
    self.navigationItem.titleView = imageView
    //location manager
    locationManager.delegate = self;
    locationManager.requestAlwaysAuthorization();
    
   

    
    
    

    
  }
  
  override func viewWillAppear(_ animated: Bool) {
    //mapView.showsUserLocation=true;
      mapView.zoomToUserLocation()
    
    //firebase get data
    
    let docRef = db.collection("cinder").document((self.appDelegate?.sharedMail)!)
    docRef.getDocument { (document, error) in
      if let document = document, document.exists {
          let results = document.data()
        if let loc = results!["Dog_loc"] as? [String: Any] {
          let firstName = results!["Dog_name"] as? String
          print(firstName!)
          
          let myLocation = CLLocationCoordinate2D(latitude:loc["Latitude"] as! CLLocationDegrees , longitude: loc["Longitude"] as! CLLocationDegrees)
          
          let geo = Geotification.init(coordinate: myLocation, radius: 100, identifier: (results!["Place_ID"] as? String)!, name: (results!["Dog_name"] as? String)!)
          
            self.add(geotification: geo)
          
          
          //CLLocationCoordinate2D
        }
        
        
        let dataDescription = document.data().map(String.init(describing:)) ?? "nil"
        print("Document data: \(dataDescription)")
      } else {
        print("Document does not exist")
      }
    }
    
    
    
    
    
    
    
    
    db.collection("cinder").getDocuments() { (querySnapshot, err) in
      if let err = err {
        print("Error getting documents: \(err)")
      } else if let querySnapshot = querySnapshot {
        for document in querySnapshot.documents {
          let results = document.data()
          if let loc = results["Dog_loc"] as? [String: Any] {
            let firstName = results["Dog_name"] as? String
            print(firstName!)
            
            let myLocation = CLLocationCoordinate2D(latitude:loc["Latitude"] as! CLLocationDegrees , longitude: loc["Longitude"] as! CLLocationDegrees)
            
            let geo = Geotification.init(coordinate: myLocation, radius: 100, identifier: (results["Place_ID"] as? String)!, name: (results["Dog_name"] as? String)!)
            if self.appDelegate?.sharedMail == (results["user_email"] as? String)!
            {
               self.addAllToFakeMap(geotification: geo)
            }
           
            //CLLocationCoordinate2D
          }
        }
      }
    }
    
  }
  
  //Segue and passing data.
  override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    if segue.identifier == "addGeotification" {
      let navigationController = segue.destination as! UINavigationController
      let vc = navigationController.viewControllers.first as! addPinsVC
      vc.delegate = self
    }
  }
  
 /* // MARK: Loading and saving functions
  func loadAllGeotifications(sender:Geotification) {
    geotifications = []
    guard let savedItems = UserDefaults.standard.array(forKey: PreferencesKeys.savedItems) else { return }
    for savedItem in sender {
      guard let geotification = NSKeyedUnarchiver.unarchiveObject(with: savedItem as! Data) as? Geotification else { continue }
      add(geotification: geotification)
    }
  }
  */
  
  
  // Functions that update the model/associated views with geotification changes
  func add(geotification: Geotification) {
    if geotifications.count<2 {
      geotifications.append(geotification)
      mapView.addAnnotation(geotification)
      addRadiusOverlay(forGeotification: geotification)
     
    }else{
      
     showAlert(withTitle: "Warning", message: "At most two Dogs!")
    }
   
  }
  
  func addAllToFakeMap(geotification: Geotification) {
 
      geotifications.append(geotification)
      fakeMapView.addAnnotation(geotification)
      addRadiusOverlay(forGeotification: geotification)
      
  
    
  }
  
  func remove(geotification: Geotification) {
    if let indexInArray = geotifications.index(of: geotification) {
      geotifications.remove(at: indexInArray)
    }
    mapView.removeAnnotation(geotification)
    removeRadiusOverlay(forGeotification: geotification)
    
     db.collection("cinder").document("")
   
  }
  
 
  
  // MARK: Map overlay functions
  func addRadiusOverlay(forGeotification geotification: Geotification) {
    mapView?.addOverlay(MKCircle(center: geotification.coordinate, radius: geotification.radius))
  }
  
  func removeRadiusOverlay(forGeotification geotification: Geotification) {
    // Find exactly one overlay which has the same coordinates & radius to remove
    guard let overlays = mapView?.overlays else { return }
    for overlay in overlays {
      guard let circleOverlay = overlay as? MKCircle else { continue }
      let coord = circleOverlay.coordinate
      if coord.latitude == geotification.coordinate.latitude && coord.longitude == geotification.coordinate.longitude && circleOverlay.radius == geotification.radius {
        mapView?.removeOverlay(circleOverlay)
        break
      }
    }
  }
  
  // MARK: Other mapview functions
  @IBAction func zoomToCurrentLocation(sender: AnyObject) {
    mapView.zoomToUserLocation()
  }
  
  func region(withGeotification geotification: Geotification) -> CLCircularRegion {
    
    let region = CLCircularRegion(center: geotification.coordinate, radius: geotification.radius, identifier: geotification.identifier)
    
    region.notifyOnExit = !region.notifyOnEntry
    return region
  }
  
  func startMonitoring(geotification: Geotification) {
    // 1
    if !CLLocationManager.isMonitoringAvailable(for: CLCircularRegion.self) {
      showAlert(withTitle:"Error", message: "Geofencing is not supported on this device!")
      return
    }
    // 2
    if CLLocationManager.authorizationStatus() != .authorizedAlways {
      showAlert(withTitle:"Warning", message: "Your geotification is saved but will only be activated once you grant Geotify permission to access the device location.")
    }
    // 3
    let region = self.region(withGeotification: geotification)
    // 4
    locationManager.startMonitoring(for: region)
  }
  
  func stopMonitoring(geotification: Geotification) {
   for region in locationManager.monitoredRegions {
      guard let circularRegion = region as? CLCircularRegion, circularRegion.identifier == geotification.identifier else { continue }
      locationManager.stopMonitoring(for: circularRegion)
    }
  }
}

// MARK: addPin delegate
extension mainMapVC: AddPinDelegate {
  
  func addPinViewController(controller: addPinsVC, didAddCoordinate coordinate: CLLocationCoordinate2D, radius: Double, identifier: String, name: String) {
    controller.dismiss(animated: true, completion: nil)
    // 1
    let clampedRadius = min(radius, locationManager.maximumRegionMonitoringDistance)
    let geotification = Geotification(coordinate: coordinate, radius: clampedRadius, identifier: identifier, name: name)
    add(geotification: geotification)
    // 2
    startMonitoring(geotification: geotification)
  }

}

// MARK: - Location Manager Delegate
extension mainMapVC: CLLocationManagerDelegate {
  
  func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
    mapView.showsUserLocation = status == .authorizedAlways
  }
  
  func locationManager(_ manager: CLLocationManager, monitoringDidFailFor region: CLRegion?, withError error: Error) {
    print("Monitoring failed for region with identifier: \(region!.identifier)")
  }
  
  func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
    print("Location Manager failed with the following error: \(error)")
  }

}

// MARK: - MapView Delegate
extension mainMapVC: MKMapViewDelegate {
  
  func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
    let identifier = "myGeotification"
    if annotation is Geotification {
      var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier) as? MKPinAnnotationView
      if annotationView == nil {
        annotationView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
        annotationView?.canShowCallout = true
        let removeButton = UIButton(type: .custom)
        removeButton.frame = CGRect(x: 0, y: 0, width: 23, height: 23)
        removeButton.setImage(UIImage(named: "DeleteGeotification")!, for: .normal)
        annotationView?.leftCalloutAccessoryView = removeButton
      } else {
        annotationView?.annotation = annotation
      }
      return annotationView
    }
    return nil
  }
  
  //Circle
  func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
    if overlay is MKCircle {
      let circleRenderer = MKCircleRenderer(overlay: overlay)
      circleRenderer.lineWidth = 1.0
      circleRenderer.strokeColor = .purple
      circleRenderer.fillColor = UIColor.purple.withAlphaComponent(0.4)
      return circleRenderer
    }
    return MKOverlayRenderer(overlay: overlay)
  }
  
  func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
    // Delete geotification
    let geotification = view.annotation as! Geotification
    remove(geotification: geotification)
  }
  
  
  
  //sign out
  @IBAction func signOut(){
    do {
      try! Auth.auth().signOut()
      
      let appDelegate = UIApplication.shared.delegate as? AppDelegate
      appDelegate?.sharedFlg="T"
      
      
      if let viewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "StartViewController") as? StartViewController {
        if let navigator = navigationController {
          navigator.pushViewController(viewController, animated: false)

          
        }
      }
      
      
      
      
    } catch let signOutError as NSError {
      showAlert(withTitle: "Error", message: signOutError.localizedDescription)
    }
  
    
  }
}
