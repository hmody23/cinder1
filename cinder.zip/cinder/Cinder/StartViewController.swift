//
//  StartViewController.swift
//  Cinder
//
//  Created by ios developer on 11/19/18.
//  Copyright © 2018 Ken Toh. All rights reserved.
//

import UIKit
import Firebase

class StartViewController: UIViewController {
  var gradient: CAGradientLayer?
  let appDelegate = UIApplication.shared.delegate as? AppDelegate

  override func viewDidLoad() {
    super.viewDidLoad()
    addGradient()
  }
  override func viewDidAppear(_ animated: Bool) {
    super.viewDidAppear(animated)
    
    if Auth.auth().currentUser != nil {
      appDelegate?.sharedMail =  Auth.auth().currentUser?.email
      appDelegate?.sharedUID =  Auth.auth().currentUser?.uid
      self.performSegue(withIdentifier: "alreadyLoggedIn", sender: nil)
    }else{
      appDelegate?.sharedMail = ""
      appDelegate?.sharedUID =  ""
    }
    
  }
  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(true)
    // Show the Navigation Bar
    self.navigationController?.setNavigationBarHidden(true, animated: true)
    
    if appDelegate?.sharedFlg=="T" {
      self.navigationItem.setHidesBackButton(true, animated:true);
    }else{
      self.navigationItem.setHidesBackButton(false, animated:true);
    }
  }
  func addGradient() {
    gradient = CAGradientLayer()
    let startColor = UIColor(red: 3/255, green: 196/255, blue: 190/255, alpha: 1)
    let endColor = UIColor(red: 0, green: 0, blue: 0, alpha: 1)
    gradient?.colors = [startColor.cgColor,endColor.cgColor]
    gradient?.startPoint = CGPoint(x: 0, y: 0)
    gradient?.endPoint = CGPoint(x: 0, y:1)
    gradient?.frame = view.frame
    self.view.layer.insertSublayer(gradient!, at: 0)
  }
  
 
  override func viewWillDisappear(_ animated: Bool) {
    super.viewWillDisappear(true)
    // Hide the Navigation Bar
    self.navigationController?.setNavigationBarHidden(false, animated: false)
  }
}
